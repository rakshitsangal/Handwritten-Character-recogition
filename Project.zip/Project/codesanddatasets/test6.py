from torchvision import datasets
import PIL
from skimage.features import local_binary_pattern,greycomatrix,greycoprops
from skimage.filters import gabor
import numpy as np
import pickle
import matplotlib.pyplot as plt
